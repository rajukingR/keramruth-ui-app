import React from 'react';
import MainNavigator from './navigation/BottomTabs';

export default function App() {
  return <MainNavigator />;
}
