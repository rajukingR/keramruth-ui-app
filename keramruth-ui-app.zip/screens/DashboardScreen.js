import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
} from "react-native";

const DashboardScreen = () => {
  return (
    <ScrollView style={styles.container}>
      {/* Header Section */}
      <View style={styles.header}>
        {/* Logo on left */}
        <Image
          source={require("../assets/logo.webp")}
          style={styles.logo}
          resizeMode="contain"
        />

        {/* Search box in center */}
        <View style={styles.searchContainer}>
          <Text style={styles.searchText}>Search</Text>
        </View>
      </View>

      {/* User Profile Section */}
      <View style={styles.profileCard}>
        <View style={styles.profileImageContainer}>
          <Image
            source={require('../assets/logo.webp')}
            style={styles.profileImage}
          />
        </View>
        <Text style={styles.userName}>Darsh</Text>
        <Text style={styles.userRole}>MS4456 | Master Distributor</Text>
        <View style={styles.clubBadge}>
          <Text style={styles.clubText}>Club: 1000 Litres</Text>
        </View>
      </View>


      {/* Stock Section */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Stock</Text>
        <View style={styles.stockInfo}>
          <Text style={styles.stockAmount}>240L/500L</Text>
          <Text style={styles.stockPercent}>48%</Text>
        </View>
        <View style={styles.stockItems}>
          <View style={styles.stockItem}>
            <Text style={styles.stockItemText}>500L</Text>
          </View>
          <View style={styles.stockItem}>
            <Text style={styles.stockItemText}>240L</Text>
          </View>
          <View style={styles.stockItem}>
            <Text style={styles.stockItemText}>240L</Text>
          </View>
        </View>
      </View>

      {/* Monthly Input Section */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Monthly Input</Text>
        <View style={styles.achievedBadge}>
          <Text style={styles.achievedText}>Achieved</Text>
        </View>
        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.printButton}>
            <Text style={styles.buttonText}>Printing</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.orderButton}>
            <Text style={styles.buttonText}>BOOK ORDER</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Stats Section */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>+110</Text>
          <Text style={styles.statLabel}>Super Distributors</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>120</Text>
          <Text style={styles.statLabel}>Distributors</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>134</Text>
          <Text style={styles.statLabel}>Customers</Text>
        </View>
      </View>

      {/* Recent Members Section */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Recent Members</Text>
        <View style={styles.memberItem}>
          <Text style={styles.memberName}>Chakradhar</Text>
          <Text style={styles.memberDetails}>
            15 Mar-24 Joined | 554985 | +91958655878
          </Text>
        </View>
        <View style={styles.memberItem}>
          <Text style={styles.memberName}>Kabir</Text>
          <Text style={styles.memberDetails}>
            12 Mar-24 Joined | 556542 | +91958655847
          </Text>
        </View>
        <View style={styles.memberItem}>
          <Text style={styles.memberName}>Imaran</Text>
          <Text style={styles.memberDetails}>
            12 Mar-24 Joined | 556387 | +91958655847
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
    padding: 16,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  logo: {
    width: 100,
    height: 100,
  },
  searchContainer: {
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 15,
    marginHorizontal: 10,
  },
  searchText: {
    color: "#888",
  },
  headerProfile: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e6f7ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerProfileIcon: {
    width: 24,
    height: 24,
  },
  profileCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
   
  },
  profileImageContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    overflow: 'hidden',
    borderWidth: 3,
    borderColor: '#e6f7ff',
  },
  profileImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  userName: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 4,
    color: '#333',
  },
  userRole: {
    fontSize: 16,
    color: '#666',
    marginBottom: 16,
    textAlign: 'center',
  },
  clubBadge: {
    backgroundColor: '#e6f7ff',
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 16,
  },
  clubText: {
    color: '#1890ff',
    fontSize: 14,
    fontWeight: '500',
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 16,
  },
  stockInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  stockAmount: {
    fontSize: 16,
  },
  stockPercent: {
    fontSize: 16,
    color: "#52c41a",
    fontWeight: "bold",
  },
  stockItems: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  stockItem: {
    backgroundColor: "#f0f0f0",
    borderRadius: 8,
    padding: 12,
    width: "30%",
    alignItems: "center",
  },
  stockItemText: {
    fontWeight: "bold",
  },
  achievedBadge: {
    backgroundColor: "#f6ffed",
    borderColor: "#b7eb8f",
    borderWidth: 1,
    borderRadius: 4,
    padding: 8,
    marginBottom: 16,
    alignItems: "center",
  },
  achievedText: {
    color: "#52c41a",
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  printButton: {
    backgroundColor: "#1890ff",
    borderRadius: 5,
    padding: 12,
    width: "48%",
  },
  orderButton: {
    backgroundColor: "#52c41a",
    borderRadius: 5,
    padding: 12,
    width: "48%",
  },
  buttonText: {
    color: "#fff",
    textAlign: "center",
    fontWeight: "bold",
  },
  statsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  statCard: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 12,
    width: "30%",
    alignItems: "center",
    elevation: 2,
  },
  statNumber: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1890ff",
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: "#666",
    textAlign: "center",
  },
  memberItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  memberName: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 4,
  },
  memberDetails: {
    fontSize: 12,
    color: "#666",
  },
});

export default DashboardScreen;
